import RPi.GPIO as GPIO
import cv2
import numpy as np
import serial
import pygame
from time import sleep
import keyboard as kb

# Defining GPIO Modes
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Making array of common labels
classnames = ['background',
              'aeroplane', 'bicycle', 'bird', 'boat',
              'bottle', 'bus', 'car', 'cat', 'chair',
              'cow', 'diningtable', 'dog', 'horse',
              'motorbike', 'person', 'pottedplant',
              'sheep', 'sofa', 'train', 'tvmonitor']

# Making path variables and sending them to deep neural network algorithm
names_path = r"deploy.prototxt"
weights_path = r"mobilenet_iter_73000.caffemodel"
net = cv2.dnn.readNetFromCaffe(names_path, weights_path)
color_g = (0, 255, 0)
color_r = (0, 0, 255)
color_b = (255, 0, 0)
color_y = (0, 255, 255)
color_o = (0, 165, 255)

# Using Webcam
cap = cv2.VideoCapture(0)
cap.set(3, 320)  # 640
cap.set(4, 240)  # 480

# Creating Arduino object
arduinoData = serial.Serial('/dev/ttyACM0', 9600)
sleep(1)

# Defining distance variables
data = []
limit1 = 30
limit2 = 15

# Defining pins
Ena = 25
In1 = 23
In2 = 24
Enb = 18
In3 = 15
In4 = 14

# Setting up pin modes
GPIO.setup(Ena, GPIO.OUT)
GPIO.setup(In1, GPIO.OUT)
GPIO.setup(In2, GPIO.OUT)
GPIO.setup(Enb, GPIO.OUT)
GPIO.setup(In3, GPIO.OUT)
GPIO.setup(In4, GPIO.OUT)

# Setting up pins speed
pwmA = GPIO.PWM(Ena, 100)
pwmA.start(0)
pwmB = GPIO.PWM(Enb, 100)
pwmB.start(0)


#############################################################
# -----------------DEFINING MOTORS FUNCTIONS-----------------#
#############################################################

def min_speed():
    pwmA.ChangeDutyCycle(40)
    pwmB.ChangeDutyCycle(40)


def med_speed():
    pwmA.ChangeDutyCycle(75)
    pwmB.ChangeDutyCycle(75)


def max_speed():
    pwmA.ChangeDutyCycle(90)
    pwmB.ChangeDutyCycle(90)


def m_forward():
    GPIO.output(In1, GPIO.LOW)
    GPIO.output(In2, GPIO.HIGH)
    GPIO.output(In3, GPIO.HIGH)
    GPIO.output(In4, GPIO.LOW)


def m_back():
    GPIO.output(In1, GPIO.HIGH)
    GPIO.output(In2, GPIO.LOW)
    GPIO.output(In3, GPIO.LOW)
    GPIO.output(In4, GPIO.HIGH)


def stop():
    pwmA.ChangeDutyCycle(0)
    pwmB.ChangeDutyCycle(0)


def m_right():
    pwmA.ChangeDutyCycle(100)
    pwmB.ChangeDutyCycle(0)
    GPIO.output(In1, GPIO.LOW)
    GPIO.output(In2, GPIO.HIGH)
    GPIO.output(In3, GPIO.LOW)
    GPIO.output(In4, GPIO.LOW)


def m_left():
    pwmA.ChangeDutyCycle(0)
    pwmB.ChangeDutyCycle(100)
    GPIO.output(In1, GPIO.LOW)
    GPIO.output(In2, GPIO.LOW)
    GPIO.output(In3, GPIO.HIGH)
    GPIO.output(In4, GPIO.LOW)


def rotate_left():
    pwmA.ChangeDutyCycle(100)
    pwmB.ChangeDutyCycle(100)
    GPIO.output(In1, GPIO.HIGH)
    GPIO.output(In2, GPIO.LOW)
    GPIO.output(In3, GPIO.HIGH)
    GPIO.output(In4, GPIO.LOW)


def rotate_right():
    pwmA.ChangeDutyCycle(100)
    pwmB.ChangeDutyCycle(100)
    GPIO.output(In1, GPIO.LOW)
    GPIO.output(In2, GPIO.HIGH)
    GPIO.output(In3, GPIO.LOW)
    GPIO.output(In4, GPIO.HIGH)


# Pygame initialization
def init():
    pygame.init()
    pygame.display.set_mode((100, 100))


def getKey(keyname):
    ans = False
    for _ in pygame.event.get():
        pass
    keyInput = pygame.key.get_pressed()
    myKey = getattr(pygame, 'K_{}'.format(keyname))
    if keyInput[myKey]:
        ans = True
    pygame.display.update()
    return ans


def Manual_Maneuver():
    if getKey('LEFT'):
        print('TURN LEFT')
        m_left()
    elif getKey('RIGHT'):
        print('TURN RIGHT')
        m_right()
    elif getKey('UP'):
        print('GO FORWARD')
        med_speed()
        m_forward()
    elif getKey('DOWN'):
        print('GO BACKWARDS')
        min_speed()
        m_back()
    else:
        print('STOP')
        stop()


def get_distance_data():
    dataPacket = arduinoData.readline()
    dataPacket = str(dataPacket, 'utf-8')
    splitPacket = dataPacket.split(',')

    front = float(splitPacket[0])
    right = float(splitPacket[1])
    left = float(splitPacket[2])
    back = float(splitPacket[3])

    # Saving Data into array
    data = [int(front), int(right), int(left), int(back)]
    print(data)
    return data


def obstacle_avoidance():
    myData = get_distance_data()
    front_distance = myData[0]
    right_distance = myData[1]
    left_distance = myData[2]
    back_distance = myData[3]

    if front_distance <= limit1:
        max_speed()
        m_back()
        sleep(0.7)

        if right_distance > left_distance:
            if right_distance <= limit1 and left_distance <= limit1:

                max_speed()
                m_back()
                sleep(0.5)
            else:
                m_right()
                sleep(1)
        elif right_distance < left_distance:
            if right_distance <= limit1 and left_distance <= limit1:

                max_speed()
                m_back()
                sleep(0.5)
            else:
                m_left()
                sleep(1)
        elif right_distance <= limit2:
            rotate_left()
            sleep(2.5)
        elif left_distance <= limit2:
            rotate_right()
            sleep(2.5)
    else:
        min_speed()
        m_forward()
        med_speed()
        m_forward()


def get_camera_view():
    success, img = cap.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (11, 11), 0)
    canny = cv2.Canny(blur, 30, 150, 3)
    dilated = cv2.dilate(canny, (0.5, 0.5), iterations=2)
    (cnt, hierarchy) = cv2.findContours(dilated.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    cv2.drawContours(rgb, cnt, -1, (0, 255, 255), 2)
    cv2.imshow("Edge Detection View", dilated)
    cv2.imshow("Contour View", rgb)
    cv2.imshow("Gray Scale View", gray)
    cv2.imshow("Real View", img)
    h, w = img.shape[0], img.shape[1]
    img_resize = cv2.resize(img, (100, 100))
    blob = cv2.dnn.blobFromImage(img_resize, 0.007843, (100, 100), 127.5)
    net.setInput(blob)
    detections = net.forward()
    for i in np.arange(0, detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.5:
            idx = int(detections[0, 0, i, 1])
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            (startX, startY, endX, endY) = box.astype('int')
            label = "{}: {:.2f}%".format(classnames[idx], confidence * 100)
            cv2.rectangle(img, (startX, startY), (endX, endY), color_o, 5)
            y = startY - 15 if startY - 15 > 15 else startY + 15
            cv2.putText(img, label, (startX, y), cv2.FONT_HERSHEY_PLAIN, 3, color_y, 3)
    cv2.imshow("Real Time View", img)
    cv2.waitKey(1)


stop()
init()

while True:
    get_camera_view()
    if kb.read_key() == "o":
        print("INITIALIZING OBSTACLE AVOIDANCE MODE")
        obstacle_avoidance()
    if kb.read_key() == "m":
        print("INITIALIZING MANUAL MANEUVER MODE")
        Manual_Maneuver()
