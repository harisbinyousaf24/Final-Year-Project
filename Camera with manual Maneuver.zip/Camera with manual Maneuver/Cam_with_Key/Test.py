import keyboard as kb
while True:
    if kb.read_key() == "w":
        print("Key UP was pressed")
    if kb.read_key() == "a":
        print("Key Left was pressed")